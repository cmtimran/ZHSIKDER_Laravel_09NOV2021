    <div class="col-sm-12">
       <div class="panel" style="background-color:#2C2A23;">
          <p style="color:white;margin-left:20px;">@yield('breadcrumbs')</p>
       </div>
       <div style="background-color:#fff">
          @yield('student_dasboard_content')
       </div>
     </div>
   </div>

</body>
 </html
