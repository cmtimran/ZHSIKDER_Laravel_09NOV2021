<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class payment_receipt_child_model extends Model
{
    protected $table="payment_receipt_child";
    protected $primaryKey="payment_receipt_child_id";
}
