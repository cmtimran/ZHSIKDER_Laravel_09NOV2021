<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shift_model extends Model
{
    protected $table='tbl_shift';
    protected $primaryKey='shift_id';
  
    
}
