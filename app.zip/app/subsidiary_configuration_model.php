<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subsidiary_configuration_model extends Model
{
    
    protected $table='subsidiary_configuration';
    // protected $primaryKey='applicant_id';
    protected $primaryKey='configuration_id';

    
}
