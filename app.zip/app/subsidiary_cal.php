<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subsidiary_cal extends Model
{
    protected $table="subsidiary_cal";
    protected $primaryKey='trancation_id';
}

