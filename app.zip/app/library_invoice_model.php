<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class library_invoice_model extends Model
{
    //
}
