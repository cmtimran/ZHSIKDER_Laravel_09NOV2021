<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class payment_receipt_model extends Model
{
    protected $table="payment_receipt";
    protected $primaryKey="payment_receipt_id";

    
}
