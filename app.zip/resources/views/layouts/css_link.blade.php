<link rel="stylesheet" href="{{URL::asset('css/bootstrap.min.css')}}" />
{{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">--}}
<link rel="stylesheet" href="{{URL::asset('css/bootstrap-responsive.min.css')}}" />
<link rel="stylesheet" href="{{URL::asset('css/fullcalendar.css')}}" />
<link rel="stylesheet" href="{{URL::asset('css/matrix-style.css')}}" />
<link rel="stylesheet" href="{{URL::asset('css/matrix-media.css')}}" />
<link rel="stylesheet" href="{{URL::asset('css/style.css')}}" />
<link rel="stylesheet" href="{{URL::asset('css/custom_css.css')}}" />
<link rel="stylesheet" href="{{URL::asset('css/msgstyle.css')}}" />
<link rel="stylesheet" href="{{URL::asset('font-awesome/css/font-awesome.css')}}"  />
<link rel="stylesheet" href="{{URL::asset('css/colorpicker.css')}}"  />
<link rel="stylesheet" href="{{URL::asset('css/datepicker.css')}}"  />
<link rel="stylesheet" href="{{URL::asset('css/uniform.css')}}"  />
<link rel="stylesheet" href="{{URL::asset('css/bootstrap-wysihtml5.css')}}"  />
{{-- <link rel="stylesheet" href="{{URL::asset('Beta/css/select2.css')}}" /> --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
@yield('style')
<script>
    var baseUrl = "{{url('/')}}";
</script>

<!-- 
<link rel="stylesheet" href="Beta/css/colorpicker.css" />
<link rel="stylesheet" href="Beta/css/datepicker.css" />
<link rel="stylesheet" href="Beta/css/uniform.css" />
<link rel="stylesheet" href="Beta/css/select2.css" />
<link rel="stylesheet" href="Beta/css/bootstrap-wysihtml5.css" /> -->

<!-- <link rel="stylesheet" href="Beta/css/bootstrap.min.css" />
<link rel="stylesheet" href="Beta/css/bootstrap-responsive.min.css" /> -->

<!-- 
<link rel="stylesheet" href="Beta/css/matrix-style.css" />
<link rel="stylesheet" href="Beta/css/matrix-media.css" />

<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'> -->




<!-- <link rel="stylesheet" href="{{URL::asset('css/noticeboardstyle.css')}}" /> -->
<!-- <link rel="stylesheet" href="{{URL::asset('css/jquery-ui.css')}}" /> -->
<!-- < <link rel="stylesheet" href="{{URL::asset('css/jquery.gritter.css')}}" />  -->
