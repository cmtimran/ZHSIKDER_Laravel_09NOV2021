<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb">
    	<a href="/" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>Home</a>
    	<a href="@yield('breadcrumbs_link')" title="@yield('breadcrumbs_title')" class="tip-bottom">@yield('breadcrumbs')</a>
    </div>
  </div>
<!--End-breadcrumbs-->

<div class="container-fluid">
