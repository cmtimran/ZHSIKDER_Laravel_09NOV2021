<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class student_payment_entry extends Model
{
    //
}
