</div>
</div>
<div class="row-fluid">
  <div id="footer" class="span12"> {{date('Y')}}&copy;Develop By:All rights Reserved By NICE Software Ltd.
  </div>
</div>
