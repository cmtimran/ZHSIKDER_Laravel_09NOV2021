<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class student_promoation extends Model
{
    //
}
