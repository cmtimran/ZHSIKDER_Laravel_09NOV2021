<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class language_settings extends Model
{
    //
}
