<script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>

<!--end-Footer-part-->
@include('layouts.js_link')
</body>
</html>
