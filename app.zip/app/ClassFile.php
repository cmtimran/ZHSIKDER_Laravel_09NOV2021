<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClassFile extends Model
{
    protected $table ='class_files';
}
