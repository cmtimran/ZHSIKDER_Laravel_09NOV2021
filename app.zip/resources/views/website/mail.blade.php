<!DOCTYPE html>
<html>
<head>
    <title>Mail</title>
</head>
<body>
    <p>{{$data['name']}}</p>
    <p>{{$data['email']}}</p>
    <p>{{$data['phone']}}</p>
    <br>
    <br>
    <p>{{$data['message']}}</p>
   
</body>
</html>