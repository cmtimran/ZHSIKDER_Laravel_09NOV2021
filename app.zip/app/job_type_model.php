<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class job_type_model extends Model
{
    protected $table='tbl_job_type';
    protected $primaryKey='job_type_id';
  
   
}
