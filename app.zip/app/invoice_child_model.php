<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invoice_child_model extends Model
{
    protected $table="invoice_child";
    protected $primaryKey="invoice_child_id";
}
