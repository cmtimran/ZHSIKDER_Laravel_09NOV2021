<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class monthly_roster_closing_model extends Model
{
    //
}
